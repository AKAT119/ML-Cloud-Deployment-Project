"use strict";


const serverUrl = "http://127.0.0.1:8000";

class HttpError extends Error {
    constructor(response) {
        super(`${response.status} for ${response.url}`);
        this.name = "HttpError";
        this.response = response;
    }
}

let audioRecorder;
let recordedAudio;
let url_recordedAudio;
let img_translated_text;

const mediaConstraints = {
    audio: true
};
navigator.getUserMedia(mediaConstraints, onMediaSuccess, onMediaError);

const maxAudioLength = 30000;
let audioFile = {};

function onMediaSuccess(audioStream) {
    audioRecorder = new MediaStreamRecorder(audioStream);
    audioRecorder.mimeType = "audio/wav";
    audioRecorder.ondataavailable = handleAudioData;
}

function onMediaError(error) {
    alert("audio recording not available: " + error.message);
}

function startRecording() {
    recordedAudio = [];
    audioRecorder.start(maxAudioLength);
}

function stopRecording() {
    audioRecorder.stop();
}

function handleAudioData(audioRecording) {
    audioRecorder.stop();

    audioFile = new File([audioRecording], "recorded_audio.wav", {type: "audio/wav"});

    let audioElem = document.getElementById("recording-player");
    audioElem.src = window.URL.createObjectURL(audioRecording);
}

let isRecording = false;

function toggleRecording() {
    let toggleBtn = document.getElementById("record-toggle");
    let translateBtn = document.getElementById("translate");

    if (isRecording) {
        toggleBtn.value = 'Record';
        translateBtn.disabled = false;
        stopRecording();
    } else {
        toggleBtn.value = 'Stop';
        translateBtn.disabled = true;
        startRecording();
    }

    isRecording = !isRecording;
}

async function uploadRecording() {
    // encode recording file as base64 string for upload
    let converter = new Promise(function(resolve, reject) {
        const reader = new FileReader();
        reader.readAsDataURL(audioFile);
        reader.onload = () => resolve(reader.result
            .toString().replace(/^data:(.*,)?/, ''));
        reader.onerror = (error) => reject(error);
    });
    let encodedString = await converter;

    // make server call to upload image
    // and return the server upload promise
    return fetch(serverUrl + "/recordings", {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({filename: audioFile.name, filebytes: encodedString})
    }).then(response => {
        if (response.ok) {
            // window.alert(response.json()['fileUrl'])
            return response.json();
        } else {
            throw new HttpError(response);
        }
    })
}

let fromLang;
let toLang = 'de';

function translateRecording(audio) {
    let fromLangElem = document.getElementById("fromLang");
    fromLang = fromLangElem[fromLangElem.selectedIndex].value;
    // let toLangElem = document.getElementById("toLang");
    // toLang = toLangElem[toLangElem.selectedIndex].value;

    // start translation text spinner
    let textSpinner = document.getElementById("text-spinner");
    textSpinner.hidden = false;
    url_recordedAudio = audio["fileUrl"];
    // make server call to transcribe recorded audio
    return fetch(serverUrl + "/recordings/" + audio["fileId"] + "/translate-text", {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({fromLang: fromLang, toLang: toLang})
    }).then(response => {
        if (response.ok) {
            return response.json();
        } else {
            throw new HttpError(response);
        }
    })
}

function updateTranslation(translation) {
    // stop translation text spinner
    let textSpinner = document.getElementById("text-spinner");
    textSpinner.hidden = true;

    let transcriptionElem = document.getElementById("transcription");
    transcriptionElem.appendChild(document.createTextNode(translation["text"]));

    let translationElem = document.getElementById("translation");
    translationElem.appendChild(document.createTextNode(translation["translation"]["translatedText"]));

    return translation
}

function synthesizeTranslation(translation) {
    // start translation audio spinner
    let audioSpinner = document.getElementById("audio-spinner");
    audioSpinner.hidden = false;

    // make server call to synthesize translation audio
    return fetch(serverUrl + "/synthesize_speech", {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({text: translation["translation"]["translatedText"], language: toLang})
    }).then(response => {
        if (response.ok) {
            return response.json();
        } else {
            throw new HttpError(response);
        }
    })
}

function updateTranslationAudio(audio) {
    // stop translation audio spinner
    let audioSpinner = document.getElementById("audio-spinner");
    audioSpinner.hidden = true;

    let audioElem = document.getElementById("translation-player");
    audioElem.src = audio["audioUrl"];
}

function uploadAndTranslate() {
    let toggleBtn = document.getElementById("record-toggle");
    toggleBtn.disabled = true;
    let translateBtn = document.getElementById("translate");
    translateBtn.disabled = true;

    uploadRecording()
        .then(audio => translateRecording(audio))
        .then(translation => updateTranslation(translation))
        .then(translation => synthesizeTranslation(translation))
        .then(audio => updateTranslationAudio(audio))
        .catch(error => {
            alert("Error: " + error);
        })

    toggleBtn.disabled = false;
}



// add function for image recognition

async function uploadImage() {
    // encode input file as base64 string for upload
    let file = document.getElementById("file").files[0];
    let converter = new Promise(function(resolve, reject) {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result
            .toString().replace(/^data:(.*,)?/, ''));
        reader.onerror = (error) => reject(error);
    });
    let encodedString = await converter;

    // clear file upload input field
    document.getElementById("file").value = "";

    // make server call to upload image
    // and return the server upload promise
    return fetch(serverUrl + "/images", {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({filename: file.name, filebytes: encodedString})
    }).then(response => {
        if (response.ok) {
            return response.json();
        } else {
            throw new HttpError(response);
        }
    })
}

function updateImage(image) {
    document.getElementById("view").style.display = "block";

    let imageElem = document.getElementById("image");
    imageElem.src = image["fileUrl"];
    imageElem.alt = image["fileId"];

    return image;
}

function translateImage(image) {
    // make server call to translate image
    // and return the server upload promise
    return fetch(serverUrl + "/images/" + image["fileId"] + "/translate-text", {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({fromLang: "auto", toLang: "de"})
    }).then(response => {
        if (response.ok) {
            return response.json();
        } else {
            throw new HttpError(response);
        }
    })
}

function annotateImage(translations) {
    let translationsElem = document.getElementById("translations");
    while (translationsElem.firstChild) {
        translationsElem.removeChild(translationsElem.firstChild);
    }
    translationsElem.clear
    var textes =''                              // add new variable here to consolidate the per line text
    for (let i = 0; i < translations.length; i++) {
        textes += translations[i]["translation"]["translatedText"] + ' '        // combine the per line text
        let translationElem = document.createElement("h6");
        translationElem.appendChild(document.createTextNode(
            translations[i]["text"] + " -> " + translations[i]["translation"]["translatedText"]
        ));
        translationsElem.appendChild(document.createElement("hr"));
        translationsElem.appendChild(translationElem);
    }
    img_translated_text = textes
    return textes // add to return the combined translated text for text-to-speech action
}
// new addition: convert translated text to audio, store in the bucket and update on the website.
function synthesizeTranslation_2(translation) {
    // start translation audio spinner
    let audioSpinner = document.getElementById("audio-spinner-2");
    audioSpinner.hidden = false;

    // make server call to synthesize translation audio
    return fetch(serverUrl + "/synthesize_speech_2", {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({text: translation, language: 'de'})
    }).then(response => {
        if (response.ok) {
            return response.json();
        } else {
            throw new HttpError(response);
        }
    })
}

function updateTranslationAudio_2(audio) {
    // stop translation audio spinner
    let audioSpinner = document.getElementById("audio-spinner-2");
    audioSpinner.hidden = true;

    let audioElem = document.getElementById("translation-player-2");
    audioElem.src = audio["audioUrl"];
}

// end addition

// end function save Translation

function uploadAndTranslate_2() {
    uploadImage()
        .then(image => updateImage(image))
        .then(image => translateImage(image))
        .then(translations => annotateImage(translations))
        .then(translation => synthesizeTranslation_2(translation)) // add new function for text-to-speech and upload
        .then(audio => updateTranslationAudio_2(audio))           // add new function for update on the website
        .catch(error => {
            alert("Error: " + error);
        })
}


document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting

    // Retrieve username and password values
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    const errorMessageDiv = document.getElementById('error-message');

    // Your login logic goes here, for example, you can send the credentials to a server-side script for verification
    // For this example, let's just log them to the console
    console.log('Username:', username);
    console.log('Password:', password);

    return fetch(serverUrl + "/login", {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({username: username, password: password})    
    })
    .then(response => { 
        if (response.ok) {
            localStorage.setItem('username', username);
            window.location.href = 'dashboard.html'; // Redirect if login is successful
        } else {
            return response.json().then(data => {
                throw new Error(data.message); // Throw an error with the error message received from the server
            });
        }
    })
    .catch(error => { 
        console.error('Error:', error);
        errorMessageDiv.textContent = 'Login failed: ' + error.message; // Display network error or other issues
        errorMessageDiv.style.display = 'block';
    });
});


function save_speech_translation() {
    var user_name = localStorage.getItem('username');
    const username = user_name;
    // const image = document.getElementById('image').src;
    const image ="";
    const original_audio = url_recordedAudio;
    const translated_text = document.getElementById('translation').textContent;
    const translated_audio = document.getElementById("translation-player").src;

    const errorMessageDiv = document.getElementById('error-message');

    return fetch(serverUrl + "/save_speech_translation", {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({username: username, image: image, original_audio: original_audio, translated_text:translated_text,translated_audio:translated_audio })    
    })
    .then(response => { 
        if (response.ok) {
            window.alert("Saved Successfully!")
        } else {
            return response.json().then(data => {
                throw new Error(data.message); // Throw an error with the error message received from the server
            });
        }
    })
    .catch(error => { 
        console.error('Error:', error);
        errorMessageDiv.textContent = 'Login failed: ' + error.message; // Display network error or other issues
        errorMessageDiv.style.display = 'block';
    });
}

function save_image_translation() {
    var user_name = localStorage.getItem('username');
    const username = user_name;
    const image = document.getElementById('image').src;
    const original_audio = "";
    const translated_text = img_translated_text;
    const translated_audio = document.getElementById("translation-player-2").src;
    const errorMessageDiv = document.getElementById('error-message');

    return fetch(serverUrl + "/save_image_translation", {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({username: username, image: image, original_audio: original_audio, translated_text:translated_text,translated_audio:translated_audio })    
    })
    .then(response => { 
        if (response.ok) {
            window.alert("Saved Successfully!")
        } else {
            return response.json().then(data => {
                throw new Error(data.message); // Throw an error with the error message received from the server
            });
        }
    })
    .catch(error => { 
        console.error('Error:', error);
        errorMessageDiv.textContent = 'Login failed: ' + error.message; // Display network error or other issues
        errorMessageDiv.style.display = 'block';
    });
}


function retrieveContacts() {
    var user_name = localStorage.getItem('username');

    // make server call to get all contacts
    return fetch(serverUrl + "/records/"+user_name, {
        method: "GET"
    }).then(response => {
        if (response.ok) {
            return response.json();
        } else {
            throw new HttpError(response);
        }
    })
}



function displayContacts(records) {
  // Get the table body element where we will be adding rows
  const tableBody = document.getElementById('records-table').getElementsByTagName('tbody')[0];
  tableBody.innerHTML = '';

// Iterate over the records and create a table row for each
records.forEach(record => {
    // Create a new row
    const row = document.createElement('tr');
  
    for (let key in record) {  
      // Create a new cell
      const cell = document.createElement('td');

      if (key === 'id' || key === 'username' || key==='date') {
        continue;
      };

      // Check if the key is for an image or audio, and create appropriate elements
      if (key === 'original_audio' || key === 'translated_audio' || key === 'image') {
        if (key === 'image') {
          const img = document.createElement('img');
          img.src = record[key];
          img.alt = 'Image';
          img.style.width = '100px'; // Set the image width
          img.style.height = 'auto'; // Set the image height to 'auto' to maintain aspect ratio
          cell.appendChild(img);
          // Add any additional image properties here
          cell.appendChild(img);
        } else {
          // For audio elements
          const audio = document.createElement('audio');
          audio.src = record[key];
          audio.controls = true;
          cell.appendChild(audio);
        }
    }
       else {
        // For text-based keys, assign the value directly to cell's textContent
        cell.textContent = record[key];
      }
  
      // Append the cell to the row
      row.appendChild(cell);
    }
    
    // Append the row to the table body
    tableBody.appendChild(row);
  });
}


function retrieveAndDisplayContacts() {
    retrieveContacts()
        .then(contacts => displayContacts(contacts))
        .catch(error => {
            alert("Error: " + error);
        })
}
