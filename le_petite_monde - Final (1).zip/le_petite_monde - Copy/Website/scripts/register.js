const serverUrl = "http://127.0.0.1:8000";

function register() {
    const username = document.getElementById('new_username').value;
    const password = document.getElementById('new_password').value;

    // Here you would typically send a request to your server to register the user
    console.log('Registering:', username, password);

    const errorMessageDiv = document.getElementById('error-message');

    return fetch(serverUrl + "/create_user", {
        method: "POST",
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({username: username, password: password})    
    })
    .then(response => { 
        if (response.ok) {
            localStorage.setItem('username', username);
            window.location.href = 'index.html'; // Redirect if login is successful
        } else {
            return response.json().then(data => {
                throw new Error(data.message); // Throw an error with the error message received from the server
            });
        }
    })
    .catch(error => { 
        console.error('Error:', error);
        errorMessageDiv.textContent = 'Login failed: ' + error.message; // Display network error or other issues
        errorMessageDiv.style.display = 'block';
    });

}
