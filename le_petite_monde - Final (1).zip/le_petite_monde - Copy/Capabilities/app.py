from chalice import Chalice
from chalice import Response
from services import storage_service
from services import transcription_service
from services import translation_service
from services import speech_service
from services import recognition_service
from services import login_service
from services import translation_store

import base64
import json

#####
# chalice app configuration
#####
app = Chalice(app_name='Capabilities')
app.debug = True

#####
# services initialization
#####
storage_location = 'contentcen_yourStudentID.aws.ai' # example: ontentcen123456789.aws.ai

storage_service = storage_service.StorageService(storage_location)
transcription_service = transcription_service.TranscriptionService(storage_service)
translation_service = translation_service.TranslationService()
speech_service = speech_service.SpeechService(storage_service)
recognition_service = recognition_service.RecognitionService(storage_service)
user_service = login_service.LoginService(region_name='us-east-1')
# store_location = 'Translations'
translation_store_service = translation_store.TranslationStore(region_name='us-east-1')
#####
# RESTful endpoints
#####

''' RECORDINGS '''
@app.route('/recordings', methods = ['POST'], cors = True)
def upload_recording():
    """processes file upload and saves file to storage service"""
    request_data = json.loads(app.current_request.raw_body)
    file_name = request_data['filename']
    file_bytes = base64.b64decode(request_data['filebytes'])

    file_info = storage_service.upload_file(file_bytes, file_name)

    return file_info


@app.route('/recordings/{recording_id}/translate-text', methods = ['POST'], cors = True)
def translate_recording(recording_id):
    """transcribes the specified audio then translates the transcription text"""
    request_data = json.loads(app.current_request.raw_body)
    from_lang = request_data['fromLang']
    to_lang = request_data['toLang']

    transcription_text = transcription_service.transcribe_audio(recording_id, from_lang)

    translation_text = translation_service.translate_text(transcription_text,
                                                          target_language = to_lang)

    return {
        'text': transcription_text,
        'translation': translation_text
    }


@app.route('/synthesize_speech', methods = ['POST'], cors = True)
def synthesize_speech():
    """performs text-to-speech on the specified text / language"""
    request_data = json.loads(app.current_request.raw_body)
    text = request_data['text']
    language = request_data['language']

    translation_audio_url = speech_service.synthesize_speech(text, language)

    return {
        'audioUrl': translation_audio_url
    }



''' REKOGNITION '''
@app.route('/images', methods = ['POST'], cors = True)
def upload_image():
    """processes file upload and saves file to storage service"""
    request_data = json.loads(app.current_request.raw_body)
    file_name = request_data['filename']
    file_bytes = base64.b64decode(request_data['filebytes'])
    image_info = storage_service.upload_file(file_bytes, file_name)
    return image_info

@app.route('/images/{image_id}/translate-text', methods = ['POST'], cors = True)
def translate_image_text(image_id):
    """detects then translates text in the specified image"""
    request_data = json.loads(app.current_request.raw_body)
    from_lang = request_data['fromLang']
    to_lang = request_data['toLang']

    MIN_CONFIDENCE = 80.0

    text_lines = recognition_service.detect_text(image_id)

    translated_lines = []
    for line in text_lines:
        # check confidence
        if float(line['confidence']) >= MIN_CONFIDENCE:
            translated_line = translation_service.translate_text(line['text'], from_lang, to_lang)
            translated_lines.append({
                'text': line['text'],
                'translation': translated_line,
                'boundingBox': line['boundingBox']
            })

    return translated_lines

# add new route
@app.route('/synthesize_speech_2', methods = ['POST'], cors = True)
def synthesize_speech_2():
    """performs text-to-speech on the specified text / language"""
    request_data = json.loads(app.current_request.raw_body)
    text = request_data['text']
    language = request_data['language']

    translation_audio_url = speech_service.synthesize_speech(text, language)

    return {
        'audioUrl': translation_audio_url
    }

@app.route('/create_user', methods=['POST'], cors = True)
def create_user():
    """Add a new user to the table."""
    data =  json.loads(app.current_request.raw_body)
    username = data.get('username')
    password = data.get('password')

    user = user_service.get_user(username)

    if user is not None:
        return  Response(body={'message': 'The user is exist!'},
        headers={'Content-Type': 'application/json'},
        status_code=401) # Password does not match, return error with HTTP status code 401 (Unauthorized)
    else:
        if username and password:
            user_service.create_user(username, password)
            return {"message": "User created successfully."}
        else:
            return  Response(body={'message': 'User and password are required'},
        headers={'Content-Type': 'application/json'},
        status_code=401) # Password does not match, return error with HTTP status code 401 (Unauthorized)

@app.route('/login', methods=['POST'], cors = True)
def get_user():
    """Retrieve a user from the table by username."""
    data =  json.loads(app.current_request.raw_body)
    username = data.get('username')
    password = data.get('password')

    user = user_service.get_user(username)
    if user is not None:
        if user.get('password') == password:
            return  Response(body=user,
                    headers={'Content-Type': 'application/json'},
                    status_code=200)  # User found and password matches, return user data with HTTP status code 200 (OK)
        else:
            return  Response(body={'message': 'Incorrect username or password.'},
                    headers={'Content-Type': 'application/json'},
                    status_code=401) # Password does not match, return error with HTTP status code 401 (Unauthorized)
    else:
        return  Response(body={'message': 'User not registered.'},status_code=404,headers={'Content-Type': 'application/json; Content-Encoding: gzip'})


@app.route('/save_speech_translation', methods=['POST'], cors = True)
def save_translation():
    """Add a new user to the table."""
    data =  json.loads(app.current_request.raw_body)
    username = data.get('username')
    image = data.get('image')
    original_audio = data.get('original_audio')
    translated_text = data.get('translated_text')
    translated_audio = data.get('translated_audio')

    translation_store_service.save_translation(username, image, original_audio, translated_text,translated_audio)

    return {"message": "Translation is saved successfully."}

@app.route('/save_image_translation', methods=['POST'], cors = True)
def save_translation():
    """Add a new user to the table."""
    data =  json.loads(app.current_request.raw_body)
    username = data.get('username')
    image = data.get('image')
    original_audio = data.get('original_audio')
    translated_text = data.get('translated_text')
    translated_audio = data.get('translated_audio')

    translation_store_service.save_translation(username, image, original_audio, translated_text,translated_audio)

    return {"message": "Translation is saved successfully."}
 



@app.route('/records/{username}', methods = ['GET'], cors = True)
def get_all_contacts(username):
    """gets all saved contacts in the contact store service"""
    records = translation_store_service.get_translation(username)

    return records

#  @app.route('/login', methods=['GET'], cors = True)
# def get_translations():
#     """Retrieve a user from the table by username."""
#     data =  json.loads(app.current_request.raw_body)
#     username = data.get('username')
#     password = data.get('password')

#     user = user_service.get_user(username)
#     if user is not None:
#         if user.get('password') == password:
#             return  Response(body=user,
#                     headers={'Content-Type': 'application/json'},
#                     status_code=200)  # User found and password matches, return user data with HTTP status code 200 (OK)
#         else:
#             return  Response(body={'message': 'Incorrect username or password.'},
#                     headers={'Content-Type': 'application/json'},
#                     status_code=401) # Password does not match, return error with HTTP status code 401 (Unauthorized)
#     else:
#         return  Response(body={'message': 'User not registered.'},status_code=404,headers={'Content-Type': 'application/json; Content-Encoding: gzip'})
