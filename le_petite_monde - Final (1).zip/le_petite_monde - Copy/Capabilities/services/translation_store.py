import boto3
from botocore.exceptions import ClientError
import uuid
from datetime import datetime

class TranslationStore:
   def __init__(self, region_name='us-west-1'):
        """Initialize the DynamoDB connection."""
        self.dynamodb = boto3.resource('dynamodb', region_name=region_name)
        self.table = self.dynamodb.Table('TranslationStore')
        self.create_user_table()  # Call create_user_table method

   def check_table_exists(self, table_name):
       dynamodb = boto3.client('dynamodb')
       try:
            response = dynamodb.describe_table(TableName=table_name)
            print(f"Table '{table_name}' exists. Table status: {response['Table']['TableStatus']}")
            return True
       except ClientError as e:
            if e.response['Error']['Code'] == 'ResourceNotFoundException':
                print(f"Table '{table_name}' does not exist.")
            else:
                print(f"An error occurred: {e}")
            return False


   def create_user_table(self):
        if not self.check_table_exists('TranslationStore'):
            """Create the DynamoDB table if it doesn't exist."""
            try:
                table = self.dynamodb.create_table(
                    TableName='TranslationStore',
                    KeySchema=[
                        {
                            'AttributeName': 'id',
                            'KeyType': 'HASH'  # Partition key
                        },
                        {
                            'AttributeName': 'date',
                            'KeyType': 'RANGE'  # Sort key, if you want to sort by date
                        }
                    ],
                    AttributeDefinitions=[
                        {
                            'AttributeName': 'id',
                            'AttributeType': 'S'
                        },
                        {
                            'AttributeName': 'date',
                            'AttributeType': 'S' 
                        },
                    ],
                    ProvisionedThroughput={
                        'ReadCapacityUnits': 1,
                        'WriteCapacityUnits': 1
                    }

                )
                table.wait_until_exists()
                print("Table created successfully.")
            except Exception as e:
                print(f"Error creating table: {e}")


   def save_translation(self, username, image, original_audio, translated_text, translated_audio):
        """Add a new translation to the table."""
        try:
            # Generate a unique ID and the current timestamp
            unique_id = str(uuid.uuid4())
            current_time = datetime.utcnow().isoformat()
            response = self.table.put_item(
                Item={
                    'id': unique_id,
                    'date': current_time,
                    'username': username,
                    'image': image,
                    'original_audio': original_audio,
                    'translated_text': translated_text,
                    'translated_audio': translated_audio,
                }
            )
            print("Translation created successfully.")
            return response
        except Exception as e:
            print(f"Error adding user: {e}")
            return None

   def get_translation(self, username):
        """Retrieve all records from the table by username."""
        try:
            response = self.table.scan(FilterExpression=boto3.dynamodb.conditions.Attr('username').eq(username))
            if 'Items' in response:
                return response['Items']
            else:
                print("User not found.")
                return None
        except Exception as e:
            print(f"Error retrieving user: {e}")
            return None


